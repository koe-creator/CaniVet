# CaniVet - Sistema de Gestion Canina y Veterinaria

## Descripcion

CaniVet es una plataforma web integral para la administracion de clinicas veterinarias y centros de cuidado canino. El sistema centraliza procesos de autenticacion, gestion de clientes, mascotas, citas, servicios, pagos, inventario, reportes y notificaciones por correo electronico.

## Objetivo

Digitalizar y optimizar la operacion diaria del negocio veterinario, ofreciendo una solucion moderna, organizada y escalable que mejore la trazabilidad de la informacion y la calidad del servicio.

## Caracteristicas principales

- Autenticacion con Supabase Auth.
- Panel administrativo con rutas protegidas.
- CRUD para clientes, mascotas, citas, servicios, pagos e inventario.
- Modulos adicionales de suscripciones, guarderia, paseos y auditoria.
- Reportes con exportacion a CSV, JSON y formato imprimible.
- Integracion de correo electronico mediante Gmail SMTP.
- Arquitectura desacoplada entre frontend React y backend Flask.

## Tecnologias utilizadas

- Frontend: React 19, Vite, CSS.
- Backend: Flask 3, flask-cors, requests.
- Base de datos: Supabase PostgreSQL.
- Autenticacion: Supabase Auth.
- Reportes: Chart.js.
- Pagos: Stripe Payment Links.
- Control de versiones: Git y GitHub.

## Estructura general

```text
canivet/
|-- Canivet/            # Frontend React
|-- backend/            # API Flask y logica de negocio
|-- docs/               # Documentacion y entregables
|-- migration.sql       # Scripts de base de datos
|-- migration_v2.sql
|-- migration_v3.sql
`-- migration_v4.sql
```

## Instalacion

### Frontend

```bash
cd Canivet
npm install
npm run dev
```

### Backend

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## Variables de entorno importantes

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_API_URL`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_JWT_SECRET`
- `SMTP_HOST`
- `SMTP_PORT`
- `SMTP_USER`
- `SMTP_PASS`

## Documentacion incluida

- `Acta_Proyecto_CaniVet.docx`
- `Plan_Actividades_CaniVet.docx`
- `Manual_Usuario_CaniVet.docx`
- `Manual_Tecnico_CaniVet.docx`
- `Analisis_Diseno_CaniVet.docx`

## Estado del proyecto

Proyecto academico en desarrollo avanzado con modulos funcionales y paquete documental base listo para entrega.
